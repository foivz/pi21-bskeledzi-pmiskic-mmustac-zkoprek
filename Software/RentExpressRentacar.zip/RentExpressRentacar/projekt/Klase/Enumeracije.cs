﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Klase
{
    public enum Spol
    {
        Muško,
        Žensko
    }
    public enum Ugovor
    {
        NaOgraničenoVrijeme,
        Trajni
    }
    public enum TipKorisnika
    {
        Administrator,
        Moderator,
        Zaposlenik,
        Kupac
    }
    public enum NacinPlacanja
    {
        Gotovina,
        Kartica
    }
}
