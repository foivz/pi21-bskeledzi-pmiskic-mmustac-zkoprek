﻿
namespace projekt
{
    partial class PodatciOKupcuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.cvvTextBox = new System.Windows.Forms.TextBox();
            this.datumIstekaTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.odustaniButton = new System.Windows.Forms.Button();
            this.zavrsiRezervacijuButton = new System.Windows.Forms.Button();
            this.brojKarticeTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.vozackaDozvolaTextBox = new System.Windows.Forms.TextBox();
            this.oibTextBox = new System.Windows.Forms.TextBox();
            this.prezimeTextBox = new System.Windows.Forms.TextBox();
            this.imeTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mailButton = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(424, 240);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(12, 17);
            this.label7.TabIndex = 33;
            this.label7.Text = "/";
            // 
            // cvvTextBox
            // 
            this.cvvTextBox.Enabled = false;
            this.cvvTextBox.Location = new System.Drawing.Point(448, 236);
            this.cvvTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cvvTextBox.Name = "cvvTextBox";
            this.cvvTextBox.Size = new System.Drawing.Size(91, 22);
            this.cvvTextBox.TabIndex = 32;
            // 
            // datumIstekaTextBox
            // 
            this.datumIstekaTextBox.Enabled = false;
            this.datumIstekaTextBox.Location = new System.Drawing.Point(324, 236);
            this.datumIstekaTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.datumIstekaTextBox.Name = "datumIstekaTextBox";
            this.datumIstekaTextBox.Size = new System.Drawing.Size(91, 22);
            this.datumIstekaTextBox.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(320, 199);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 17);
            this.label6.TabIndex = 30;
            this.label6.Text = "Datum isteka / CVV";
            // 
            // odustaniButton
            // 
            this.odustaniButton.Location = new System.Drawing.Point(25, 354);
            this.odustaniButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.odustaniButton.Name = "odustaniButton";
            this.odustaniButton.Size = new System.Drawing.Size(115, 28);
            this.odustaniButton.TabIndex = 29;
            this.odustaniButton.Text = "Odustani";
            this.odustaniButton.UseVisualStyleBackColor = true;
            this.odustaniButton.Click += new System.EventHandler(this.odustaniButton_Click);
            // 
            // zavrsiRezervacijuButton
            // 
            this.zavrsiRezervacijuButton.Location = new System.Drawing.Point(381, 354);
            this.zavrsiRezervacijuButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.zavrsiRezervacijuButton.Name = "zavrsiRezervacijuButton";
            this.zavrsiRezervacijuButton.Size = new System.Drawing.Size(158, 28);
            this.zavrsiRezervacijuButton.TabIndex = 28;
            this.zavrsiRezervacijuButton.Text = "Završi Rezervaciju";
            this.zavrsiRezervacijuButton.UseVisualStyleBackColor = true;
            this.zavrsiRezervacijuButton.Click += new System.EventHandler(this.zavrsiRezervacijuButton_Click);
            // 
            // brojKarticeTextBox
            // 
            this.brojKarticeTextBox.Enabled = false;
            this.brojKarticeTextBox.Location = new System.Drawing.Point(16, 236);
            this.brojKarticeTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.brojKarticeTextBox.Name = "brojKarticeTextBox";
            this.brojKarticeTextBox.Size = new System.Drawing.Size(196, 22);
            this.brojKarticeTextBox.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 199);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 17);
            this.label5.TabIndex = 26;
            this.label5.Text = "Broj kartice:";
            // 
            // vozackaDozvolaTextBox
            // 
            this.vozackaDozvolaTextBox.Location = new System.Drawing.Point(324, 148);
            this.vozackaDozvolaTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.vozackaDozvolaTextBox.Name = "vozackaDozvolaTextBox";
            this.vozackaDozvolaTextBox.Size = new System.Drawing.Size(215, 22);
            this.vozackaDozvolaTextBox.TabIndex = 25;
            // 
            // oibTextBox
            // 
            this.oibTextBox.Location = new System.Drawing.Point(16, 149);
            this.oibTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.oibTextBox.Name = "oibTextBox";
            this.oibTextBox.Size = new System.Drawing.Size(196, 22);
            this.oibTextBox.TabIndex = 24;
            // 
            // prezimeTextBox
            // 
            this.prezimeTextBox.Location = new System.Drawing.Point(324, 64);
            this.prezimeTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.prezimeTextBox.Name = "prezimeTextBox";
            this.prezimeTextBox.Size = new System.Drawing.Size(215, 22);
            this.prezimeTextBox.TabIndex = 23;
            // 
            // imeTextBox
            // 
            this.imeTextBox.Location = new System.Drawing.Point(16, 65);
            this.imeTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.imeTextBox.Name = "imeTextBox";
            this.imeTextBox.Size = new System.Drawing.Size(196, 22);
            this.imeTextBox.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(320, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "Vozačka dozvola:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 112);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 20;
            this.label3.Text = "OIB:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(320, 33);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 19;
            this.label2.Text = "Prezime:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "Ime:";
            // 
            // mailButton
            // 
            this.mailButton.Location = new System.Drawing.Point(314, 290);
            this.mailButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mailButton.Name = "mailButton";
            this.mailButton.Size = new System.Drawing.Size(125, 29);
            this.mailButton.TabIndex = 34;
            this.mailButton.Text = "Pošalji na mail";
            this.mailButton.UseVisualStyleBackColor = true;
            this.mailButton.Click += new System.EventHandler(this.mailButton_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(72, 293);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(196, 22);
            this.txtEmail.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 293);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 17);
            this.label8.TabIndex = 35;
            this.label8.Text = "E-mail:";
            // 
            // PodatciOKupcuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 412);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.mailButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cvvTextBox);
            this.Controls.Add(this.datumIstekaTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.odustaniButton);
            this.Controls.Add(this.zavrsiRezervacijuButton);
            this.Controls.Add(this.brojKarticeTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.vozackaDozvolaTextBox);
            this.Controls.Add(this.oibTextBox);
            this.Controls.Add(this.prezimeTextBox);
            this.Controls.Add(this.imeTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "PodatciOKupcuForm";
            this.Text = "PODATCI O KUPCU";
            this.Load += new System.EventHandler(this.PodatciOKupcuForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox cvvTextBox;
        private System.Windows.Forms.TextBox datumIstekaTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button odustaniButton;
        private System.Windows.Forms.Button zavrsiRezervacijuButton;
        private System.Windows.Forms.TextBox brojKarticeTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox vozackaDozvolaTextBox;
        private System.Windows.Forms.TextBox oibTextBox;
        private System.Windows.Forms.TextBox prezimeTextBox;
        private System.Windows.Forms.TextBox imeTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button mailButton;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label8;
    }
}